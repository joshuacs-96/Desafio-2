#ifndef IO_H
#define IO_H
#include <cstdio>
#include "Usuario.h"
#include "Artista.h"
#include "Album.h"
#include "Cancion.h"
#include "Anuncio.h"
#include "Plataforma.h"

bool cargarUsuarios(const char* path, Plataforma& app);
bool cargarArtistas(const char* path, Plataforma& app);
bool cargarAlbums (const char* path, Plataforma& app);
bool cargarCanciones(const char* path, Plataforma& app);
bool cargarAnuncios(const char* path, Plataforma& app);

#endif
