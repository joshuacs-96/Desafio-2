#include <iostream>
#include <cstring>
#include <chrono>
#include <thread>

#include "Plataforma.h"
#include "Usuario.h"
#include "ListaFavoritos.h"
#include "Artista.h"
#include "Album.h"
#include "Cancion.h"
#include "Anuncio.h"
#include "SistemaReproduccion.h"
#include "MedidorRecursos.h"
#include "io.h"

static void pausa3s(){ std::this_thread::sleep_for(std::chrono::seconds(3)); }

static void imprimirBanner(){
    std::cout << "--------------------------------------\n";
    std::cout << "        UdeATunes - Plataforma        \n";
    std::cout << "--------------------------------------\n";
}

static void imprimirMenu(bool premium){
    std::cout << "\nMenu principal\n";
    std::cout << "1) Reproduccion aleatoria\n";
    if (premium){
        std::cout << "2) Mi Lista de Favoritos: reproducir\n";
        std::cout << "3) Mi Lista de Favoritos: agregar cancion por ID\n";
        std::cout << "4) Seguir otra lista (demo)\n";
    }
    std::cout << "0) Salir\n";
    std::cout << "Seleccione: ";
}

static void reproducirAleatoriaConAnuncios(Plataforma& app, Usuario* u, int K){
    std::cout << "--------------------------------------\n";
    std::cout << "Reproduccion Aleatoria (K=" << K << ")\n";

    for (int i=0; i<K; ++i){
        app.reproducirAleatorio();
        if (!u->Premium() && ((i+1)%2==0)){
            // Requiere Plataforma::elegirAnuncio()
            Anuncio* ad = app.elegirAnuncio();
            if (ad) std::cout << "[PUBLICIDAD] " << ad->getMensaje() << "\n";
        }
        pausa3s();
    }
}

int main(){
    imprimirBanner();

    // --- inicializar sistema ---
    SistemaReproduccion player;
    MedidorRecursos monitor;
    Plataforma app;
    app.setSistemaReproduccion(&player);
    app.setMedidor(&monitor);

    // --- cargar CSVs ---
    const char* dataDir = "data";  // cambia esta ruta si quieres
    char path[1024];

    pathJoin(dataDir, "usuarios.csv", path, 1024);    cargarUsuarios(path, app);
    pathJoin(dataDir, "artistas.csv", path, 1024);    cargarArtistas(path, app);
    pathJoin(dataDir, "albums.csv", path, 1024);      cargarAlbums(path, app);
    pathJoin(dataDir, "canciones.csv", path, 1024);   cargarCanciones(path, app);
    pathJoin(dataDir, "anuncios.csv", path, 1024);    cargarAnuncios(path, app);

    // --- login ---
    char nick[64]; char pass[64];
    std::cout << "Usuario: "; std::cin.getline(nick, 64);
    if(std::strlen(nick)==0){ std::cin.getline(nick, 64); } // enter residual
    std::cout << "Clave  : "; std::cin.getline(pass, 64);

    Usuario* activo = app.login(nick, pass);
    if (!activo){
        std::cout << "Usuario/clave invalida.\n";
        return 0;
    }
    std::cout << "Bienvenido, " << activo->getUsuario()
              << (activo->Premium()? " (Premium)\n":" (Estandar)\n");

    // Asegurar lista de favoritos
    ListaFavoritos fav(activo);
    activo->setListaFavoritos(&fav);

    bool premium = activo->Premium();
    int op = -1;
    while (op != 0){
        imprimirMenu(premium);
        std::cin >> op; std::cin.ignore(256, '\n');

        if (op == 1){
            monitor.reset();
            monitor.contarIteracion(); // ejemplo

            reproducirAleatoriaConAnuncios(app, activo, 5);

            std::cout << "--------------------------------------\n";
            std::cout << "Metricas\n";
            std::cout << "Iteraciones: " << monitor.getIteraciones() << "\n";
            std::cout << "Memoria total: " << (unsigned long long)monitor.getMemoriaTotal() << " bytes\n";
            std::cout << "--------------------------------------\n";
        } else if (op == 2 && premium){
            int L = fav.getLen();
            std::cout << "Mi Lista de Favoritos ("<< L <<")\n";
            for (int i=0;i<L;++i){
                Cancion* c = fav.getItems()[i];
                if (c){ player.reproducir(c); pausa3s(); }
            }
        } else if (op == 3 && premium){
            std::cout << "Id de cancion a agregar: ";
            int id; std::cin >> id; std::cin.ignore(256, '\n');
            Cancion* c = app.encontrarCancion(id);
            if (c){ fav.agregar(c); std::cout << "Agregada.\n"; }
            else { std::cout << "No encontrada.\n"; }
        } else if (op == 4 && premium){
            std::cout << "(Demo) Seguir otra lista: por implementar.\n";
        } else if (op == 0){
            std::cout << "Saliendo...\n";
        } else {
            std::cout << "Opcion invalida.\n";
        }
    }
    return 0;
}
