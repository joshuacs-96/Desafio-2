#include "io.h"
#include <cstring>
static bool leerLinea(FILE* f, char* buf, int n) {
    return fgets(buf, n, f) != 0;
}
static void cortarNL(char* s){ if(!s) return; size_t n=strlen(s); if(n&& (s[n-1]=='\n'||s[n-1]=='\r')) s[n-1]=0; }
static char* campo(char* s){ // devuelve puntero al próximo campo y termina el actual en '\0'
    char* p = strchr(s, ';');
    if (p) { *p = 0; return p+1; }
    return 0;
}

bool cargarUsuarios(const char* path, Plataforma& app){
    FILE* f = fopen(path, "rb"); if(!f) return false;
    char line[1024];
    while (leerLinea(f,line,1024)){
        cortarNL(line); if(!line[0]|| line[0]=='#') continue;
        char* p=line;
        char* nick=p;            p=campo(p);
        char* tipo=p? p: (char*)"";           p= p? campo(p):0;
        char* ciudad=p? p: (char*)"";         p= p? campo(p):0;
        char* pais=p? p: (char*)"";           p= p? campo(p):0;
        char* fecha=p? p: (char*)"";          p= p? campo(p):0;
        char* pass= p? p: (char*)"";
        Usuario* u = new Usuario(nick,tipo,ciudad,pais,fecha);
        // si usas password, guárdalo en Usuario (agrega campo) o ignóralo
        app.agregarUsuario(u);
    }
    fclose(f); return true;
}
